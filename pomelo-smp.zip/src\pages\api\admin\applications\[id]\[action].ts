import type { APIRoute } from 'astro';
import { WhitelistIdSchema } from '../../../../../server/schemas/whitelist';
import { ReviewSchema } from '../../../../../server/schemas/admin';
import { reviewApplication, type ReviewDecision } from '../../../../../server/services/whitelist';
import { requireAdmin } from '../../../../../server/lib/admin-auth';
import { assertSameOrigin } from '../../../../../server/lib/request';
import { AppError, json, toErrorResponse } from '../../../../../server/lib/errors';

export const prerender = false;

const ACTIONS: Record<string, ReviewDecision> = {
  approve: 'approved',
  reject: 'rejected',
};

export const POST: APIRoute = async (ctx) => {
  try {
    assertSameOrigin(ctx.request);
    const session = await requireAdmin(ctx);

    const id = WhitelistIdSchema.parse(ctx.params.id);

    const action = (ctx.params.action ?? '') as string;
    const decision = ACTIONS[action];
    if (!decision) {
      throw new AppError('not_found', `Unknown action: ${action}`);
    }

    const ct = (ctx.request.headers.get('content-type') ?? '').toLowerCase();
    let note: string | undefined;
    if (ct.startsWith('application/json')) {
      const raw = await ctx.request.text();
      if (raw.length > 4_096) throw new AppError('bad_request', 'Body too large');
      if (raw.trim().length > 0) {
        const parsed = ReviewSchema.parse(JSON.parse(raw));
        note = parsed.note;
      }
    }

    const result = await reviewApplication(id, decision, session.username, note ?? null);
    return json({ data: result, requestId: ctx.locals.requestId });
  } catch (err) {
    return toErrorResponse(err, ctx.locals.requestId);
  }
};
