# PomeloSMP 🍊

เว็บไซต์เซิร์ฟเวอร์ Minecraft **PomeloSMP** สไตล์ minimal สร้างด้วย [Astro](https://astro.build/) + [Tailwind CSS](https://tailwindcss.com/)

## คอนเซ็ปต์

- **พาเลทสี** แรงบันดาลใจจากส้มโอ — เปลือกส้มอมเหลือง, เนื้อชมพูอ่อน, ใบเขียวสดชื่น บนพื้น cream อบอุ่น
- **มินิมอล** เน้น whitespace, typography แข็งแรง, การ์ดโปร่งแสง, พาสเทลชีคี
- **ไม่มี image asset ภายนอก** — ใช้ SVG inline ทั้งหมด โหลดเร็ว ใช้งานแบบ offline-first ได้
- **2 ภาษา** — เนื้อหาเป็นภาษาไทย รองรับฟอนต์ Noto Sans Thai

## โครงสร้าง

```text
src/
├── components/
│   ├── CTA.astro         # Call-to-action + IP copy (dark)
│   ├── FAQ.astro         # คำถามที่พบบ่อย (<details> accordion)
│   ├── Features.astro    # 6 จุดเด่นของเซิร์ฟเวอร์
│   ├── Footer.astro
│   ├── Gallery.astro     # โชว์บิลด์ของชาวเซิร์ฟ (SVG pixel art)
│   ├── Hero.astro        # Hero + IP copy + สถิติ
│   ├── HowToJoin.astro   # 4 ขั้นตอนเข้าเล่น
│   ├── Logo.astro
│   ├── Nav.astro
│   └── Rules.astro       # กติกาชุมชน 6 ข้อ
├── layouts/
│   └── Layout.astro
├── pages/
│   └── index.astro
└── styles/
    └── global.css
public/
├── favicon.svg
└── og.svg
```

## เริ่มต้นใช้งาน

```bash
# ติดตั้ง dependencies
npm install

# รัน dev server (http://localhost:4321)
npm run dev

# build production
npm run build

# preview build
npm run preview
```

## ปรับแต่ง

- **เปลี่ยน IP เซิร์ฟเวอร์** — แก้ `serverIp` ใน `src/components/Hero.astro`, `src/components/CTA.astro` และ `src/components/Footer.astro`
- **เปลี่ยน Discord link** — ค้นหา `discord.gg/pomelosmp` แล้วแทนที่ทั้งหมด
- **ปรับพาเลทสี** — แก้ที่ `tailwind.config.mjs` → `theme.extend.colors.pomelo / flesh / leaf / cream / ink`
- **เปลี่ยนจำนวนผู้เล่นสด** — ตอนนี้เป็นค่า static ใน `Hero.astro` สามารถเชื่อม API เช่น `mcsrvstat.us` ได้ภายหลัง

## อัปขึ้น GitHub

มี 2 วิธี เลือกตามสะดวก:

### A) มี Git ติดตั้งในเครื่อง

```powershell
# 1) สร้าง repo เปล่าบน GitHub (เว็บ) ชื่อ pomelo-smp
# 2) ในโฟลเดอร์โปรเจกต์:
git init
git branch -M main
git add .
git commit -m "feat: initial PomeloSMP site"
git remote add origin https://github.com/<USERNAME>/pomelo-smp.git
git push -u origin main
```

หรือใช้ [GitHub CLI](https://cli.github.com/):

```powershell
gh auth login
gh repo create pomelo-smp --public --source . --remote origin --push
```

### B) ไม่มี Git — อัปโหลดผ่านเบราว์เซอร์ / Codespace

1. ซิปโฟลเดอร์โปรเจกต์ (ไม่รวม `node_modules` และ `dist`)
2. เข้า GitHub สร้าง repo ใหม่ชื่อ `pomelo-smp`
3. คลิก **"uploading an existing file"** แล้วลากไฟล์ทั้งหมดลงไป commit ได้เลย
4. หรือเปิด Codespace ของ repo นั้น แล้วลากไฟล์/โฟลเดอร์เข้า Explorer ของ VS Code ใน Codespace → `git add . && git commit -m "init" && git push`

## ใช้งานใน GitHub Codespaces

repo นี้มี `.devcontainer/devcontainer.json` ให้แล้ว เมื่อเปิด Codespace:

- ใช้ image `javascript-node:20` + GitHub CLI
- รัน `npm install` อัตโนมัติ
- พอ attach จะรัน `npm run dev -- --host 0.0.0.0`
- forward port **4321** อัตโนมัติและเปิด preview ให้

ติดตั้ง extension ที่แนะนำ: Astro, Tailwind CSS IntelliSense, Prettier, MDX

## License

MIT — ดูไฟล์ `LICENSE`

ไม่เกี่ยวข้องกับ Mojang AB / Microsoft ใด ๆ — โปรเจกต์แฟนเมดเพื่อชุมชน
