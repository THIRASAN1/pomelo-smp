import type { APIRoute } from 'astro';
import { WhitelistIdSchema } from '../../../../../server/schemas/whitelist';
import { ReviewSchema } from '../../../../../server/schemas/admin';
import { reviewApplication } from '../../../../../server/services/whitelist';
import { requireAdmin } from '../../../../../server/lib/admin-auth';
import { assertSameOrigin } from '../../../../../server/lib/request';
import { AppError, json, toErrorResponse } from '../../../../../server/lib/errors';

export const prerender = false;

/**
 * Shared approve / reject handler. Consumed by:
 *   POST /api/admin/applications/:id/approve
 *   POST /api/admin/applications/:id/reject
 *
 * Astro catch-all routes can't easily express that, so we expose both endpoints
 * and delegate here. See [action].ts below.
 */
export async function handleReview(
  ctx: Parameters<APIRoute>[0],
  decision: 'approved' | 'rejected',
): Promise<Response> {
  try {
    assertSameOrigin(ctx.request);
    const session = await requireAdmin(ctx);

    const id = WhitelistIdSchema.parse(ctx.params.id);

    const ct = (ctx.request.headers.get('content-type') ?? '').toLowerCase();
    let note: string | undefined;
    if (ct.startsWith('application/json')) {
      const raw = await ctx.request.text();
      if (raw.length > 4_096) throw new AppError('bad_request', 'Body too large');
      if (raw.trim().length > 0) {
        const parsed = ReviewSchema.parse(JSON.parse(raw));
        note = parsed.note;
      }
    }

    const result = await reviewApplication(id, decision, session.username, note ?? null);
    return json({ data: result, requestId: ctx.locals.requestId });
  } catch (err) {
    return toErrorResponse(err, ctx.locals.requestId);
  }
}
